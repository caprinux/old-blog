#! /bin/sh

build() {
    docker build -t dist_placeholder:latest .
    return
}

run() {
    docker run -d -p 1337:1337 dist_placeholder:latest
    return
}

run || (build && run)
